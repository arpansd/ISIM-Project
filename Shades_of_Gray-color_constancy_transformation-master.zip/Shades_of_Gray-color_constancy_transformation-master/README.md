# Shades_of_Gray-color_constancy_transformation
The code is an implementation of `Improving Dermoscopy Image Classification Using Color Constancy`: https://ieeexplore.ieee.org/document/6866131/


