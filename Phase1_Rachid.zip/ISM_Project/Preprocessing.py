"""Preprocessing"""


import cv2
import numpy as np
import os.path
import matplotlib.pyplot as plt
from PIL import Image
import os
from skimage.filters import threshold_otsu

"""Applying CLAHE to resolve uneven illumination"""


def Clahe(img):
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    lab_planes = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    lab_planes[0] = clahe.apply(lab_planes[0])
    lab = cv2.merge(lab_planes)
    cl1 = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return cl1


"""Shades of Gray colour constancy:Improving Dermoscopy Image Classification Using Color Constancy"""
"""
    Parameters
    ----------
    img: 2D numpy array
        The original image with format of (h, w, c)
    power: int
        The degree of norm, 6 is used in reference paper
    gamma: float
        The value of gamma correction, 2.2 is used in reference paper
    """
# Paper:https://ieeexplore.ieee.org/document/6866131/


def color_constancy(img, pw, gamma):

    img_dtype = img.dtype
    if gamma is not None:
        img = img.astype('uint8')
        look_up_table = np.ones((256, 1), dtype='uint8') * 0
        for i in range(256):
            look_up_table[i][0] = 255*pow(i/255, 1/gamma)
            img = cv2.LUT(img, look_up_table)

    img = img.astype('float32')
    img_power = np.power(img, pw)
    rgb_vec = np.power(np.mean(img_power, (0, 1)), 1/pw)
    rgb_norm = np.sqrt(np.sum(np.power(rgb_vec, 2.0)))
    rgb_vec = rgb_vec/rgb_norm
    rgb_vec = 1/(rgb_vec*np.sqrt(3))
    img = np.multiply(img, rgb_vec)
    return img.astype(img_dtype)


"""Dull_Razor: Hair Removal"""
# from: https://github.com/sunnyshah2894/DigitalHairRemoval
# Kernel size = (39,39) will be used


def dull_razor(img, ksize):
    

    # Convert the original image to grayscale

    grayScale = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # Kernel for the morphological filtering

    kernel = cv2.getStructuringElement(1, ksize)

    # Perform the blackHat filtering on the grayscale image to find the
    # hair countours

    blackhat = cv2.morphologyEx(grayScale, cv2.MORPH_BLACKHAT, kernel)

    # intensify the hair countours in preparation for the inpainting
    # algorithm

    ret, thresh2 = cv2.threshold(blackhat, 10, 255, cv2.THRESH_BINARY)

    # inpaint the original image depending on the mask

    dst = cv2.inpaint(img, thresh2, 1, cv2.INPAINT_TELEA)

    return dst
