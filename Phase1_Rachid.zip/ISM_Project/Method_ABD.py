"""
Methods to extract features (A, B, D) of a lesion.

"""
# third-party imports
import cv2
import numpy as np
from Otsu_Seg import extract_largest_contour, Otsu
import math


"""
This method extracts 7 features Asymmetry (A), Border (B), and Diamter (D)  along with
lesion area, centroid, and perimeter. Performs affine transformation
A1: Asymmetry score across x-axis
A2: Asymmetry across y-axis
B1: Area to perimeter ratio
B2: Compactness index
B3: Perimeter multiplied by area
D1: Average diameter of the lesion
D2: Diference between principal axes lengths
From: https://doi.org/10.1007/s42452-019-0786-8
"""


def extract_ABD(image, thresh, contours):
    """
    :param image: 3-d numpy array of an RGB image
    :param mask: binary image of the lesion mask image
    :param contour: list of contours points of the lesion
    :return: a list of all the features along with area, centroid,
    perimeter of the lesion, and transformed image
    """
    # Get the moments
    try:
        moments = cv2.moments(contours)
        contour_area = cv2.contourArea(contours)

        contour_centroid = [int(moments['m10'] / (moments['m00'] + 1e-5)),
                            int(moments['m01'] / (moments['m00'] + 1e-5))]
        contour_perimeter = cv2.arcLength(contours, True)

    # Get max and min diameter
        rect = cv2.fitEllipse(contours)
        (x, y) = rect[0]
        (w, h) = rect[1]
        angle = rect[2]

        if w < h:
            if angle < 90:
                angle -= 90
            else:
                angle += 90
        rows, cols = thresh.shape
        rot = cv2.getRotationMatrix2D((x, y), angle, 1)
        cos = np.abs(rot[0, 0])
        sin = np.abs(rot[0, 1])
        nW = int((rows * sin) + (cols * cos))
        nH = int((rows * cos) + (cols * sin))

        rot[0, 2] += (nW / 2) - cols / 2
        rot[1, 2] += (nH / 2) - rows / 2

        warp_mask = cv2.warpAffine(thresh, rot, (nH, nW))
        warp_img = cv2.warpAffine(image, rot, (nH, nW))
        warp_img_segmented = cv2.bitwise_and(warp_img, warp_img,
                                             mask=warp_mask)

        cnts, hierarchy = cv2.findContours(warp_mask, cv2.RETR_TREE,
                                           cv2.CHAIN_APPROX_NONE)
        areas = [cv2.contourArea(c) for c in cnts]
        contours = cnts[np.argmax(areas)]
        xx, yy, nW, nH = cv2.boundingRect(contours)
    #        cv2.rectangle(warp_mask,(xx,yy),(xx+w,yy+h),(255,255,255),2)
        warp_mask = warp_mask[yy:yy + nH, xx:xx + nW]

    # get horizontal asymmetry
        flipContourHorizontal = cv2.flip(warp_mask, 1)
        flipContourVertical = cv2.flip(warp_mask, 0)

        diff_horizontal = cv2.compare(warp_mask, flipContourHorizontal,
                                      cv2.CV_8UC1)
        diff_vertical = cv2.compare(warp_mask, flipContourVertical,
                                    cv2.CV_8UC1)

        diff_horizontal = cv2.bitwise_not(diff_horizontal)
        diff_vertical = cv2.bitwise_not(diff_vertical)

        h_asym = cv2.countNonZero(diff_horizontal)
        v_asym = cv2.countNonZero(diff_vertical)

    # Parameters for the Average diameter of the lesion D1
        D11 = math.sqrt(4*contour_area / np.pi)
        D12 = (nW + nH)/2
    # diameter max
        D_max = max([nW, nH])

        return [{'area': int(contour_area), 'centroid': contour_centroid,
                 'perimeter': int(contour_perimeter),
                 'B1': round(contour_area / contour_perimeter, 3),
                 'B2': round(
                 (4 * np.pi * contour_area) / (contour_perimeter ** 2), 3),
                 'B3': round(contour_perimeter * contour_area, 3),

                 'D1': round((D11 + D12) / 2, 3), 'D2': (max([nW, nH]) - min([nW, nH])),
                 'A1': round(float(h_asym) / contour_area, 2),
                 'A2': round(float(v_asym) / contour_area, 2)},
                cv2.bitwise_not(diff_horizontal),
                cv2.bitwise_not(diff_vertical),
                warp_img_segmented, {'D_max': D_max}]
    except:
        return {}
