import pandas as pd
import numpy as np
import os
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.utils import class_weight


def load_isic_validation_data(image_folder, ground_truth_file):
    df_ground_truth_val = pd.read_csv(ground_truth_file)
    # Category names
    known_category_names_val = list(df_ground_truth_val.columns.values[1:9])
    unknown_category_name_val = df_ground_truth_val.columns.values[9]

    # Add path and category columns
    df_ground_truth_val['Path'] = df_ground_truth_val.apply(
        lambda row: os.path.join(image_folder, row['image']), axis=1)
    df_ground_truth_val['category'] = np.argmax(
        np.array(df_ground_truth_val.iloc[:, 1:10]), axis=1)
    return df_ground_truth_val, known_category_names_val, unknown_category_name_val


def load_isic_training_data(image_folder, ground_truth_file):
    df_ground_truth = pd.read_csv(ground_truth_file)
    # Category names
    known_category_names = list(df_ground_truth.columns.values[1:9])
    unknown_category_name = df_ground_truth.columns.values[9]

    # Add path and category columns
    df_ground_truth['Path'] = df_ground_truth.apply(
        lambda row: os.path.join(image_folder, row['image']), axis=1)
    df_ground_truth['category'] = np.argmax(
        np.array(df_ground_truth.iloc[:, 1:10]), axis=1)
    return df_ground_truth, known_category_names, unknown_category_name

# Combining Training_Data with Out_Distribution_Data(7pt_DataSet+ISIC_Archive) for the unknown category


def load_isic_training_and_out_dist_data(isic_image_folder, ground_truth_file, out_dist_image_folder):
    """ISIC training data and Out-of-distribution data are combined"""
    df_ground_truth = pd.read_csv(ground_truth_file)
    # Category names
    known_category_names = list(df_ground_truth.columns.values[1:9])
    unknown_category_name = df_ground_truth.columns.values[9]

    # Add path and category columns
    df_ground_truth['path'] = df_ground_truth.apply(
        lambda row: os.path.join(isic_image_folder, row['image']), axis=1)

    df_out_dist = get_dataframe_from_img_folder(
        out_dist_image_folder, has_path_col=True)
    for name in known_category_names:
        df_out_dist[name] = 0.0
    df_out_dist[unknown_category_name] = 1.0
    # Change the order of columns
    df_out_dist = df_out_dist[df_ground_truth.columns.values]

    df_combined = pd.concat([df_ground_truth, df_out_dist])
    df_combined['category'] = np.argmax(
        np.array(df_combined.iloc[:, 1:10]), axis=1)

    category_names = known_category_names + [unknown_category_name]
    return df_combined, category_names


def get_dataframe_from_img_folder(img_folder, has_path_col=True):
    if has_path_col:
        return pd.DataFrame([[Path(x).stem, x] for x in sorted(Path(img_folder).glob('**/*'))], columns=['image', 'Path'], dtype=np.str)
    else:
        return pd.DataFrame([Path(x).stem for x in sorted(Path(img_folder).glob('**/*'))], columns=['image'], dtype=np.str)
