

import sys
import os
import json
import numpy as np
import pandas as pd
import cv2

# custom imports
import Lesion

# Initialization params
results = []
cols = ['Path', 'A1', 'A2', 'B1', 'B2', 'B3', 'C', 'A_B', 'A_R', 'A_BG', 'A_DB', 'A_LB',
                      'A_W', 'D1', 'D2']


def main(dir_path='', process_dir=True):
    """
    The method that can process  all files in a directory based
    on the arguments provided.
    :param dir_path: Directory path containing all lesion images
    :param process_dir: If true, it processes all images in a directory
    """

    if len(dir_path) != 0:

        columns = cols
        rows = []
        for name in os.listdir(dir_path):
            if not os.path.isdir(
                    name) and "lesion" not in name \
                    and "Label" not in name \
                    and name.endswith('.jpg'):
                filename = os.path.join(dir_path, name)
                print("FILE: %s" % filename)
                try:

                    lesion = Lesion.Lesion(filename)
                    lesion.preprocess()
                    lesion.segment()
                    lesion.extract_features()
                    lesion.get_color_contours()
                    # get the features_vector
                    feature_vector = np.array([lesion.feature_set[col]
                                               for col in cols])

                    rows.append(feature_vector)
                    target_csv = pd.DataFrame(rows, columns=columns)
                except:
                    feature_vector = np.zeros(len(cols))
                    print(
                        'features of this image need to be seperate extracted:', filename)
                    rows.append(feature_vector)
                    target_csv = pd.DataFrame(rows, columns=columns)
        # saving the extracted features un CSV file
        results_folder = os.path.join(dir_path, "features_results.csv")
        target_csv.to_csv(results_folder, index=False)

    else:
        print("Invalid directory")


if __name__ == "__main__":

    #main(dir_path='Data_Image\ISIC_2019_Test_Input', process_dir=True)
