""" Segmentation"""

import matplotlib.pyplot as plt
from skimage import data
from skimage import filters
from skimage import exposure
import cv2
import numpy as np
from skimage import data, img_as_float
from skimage.segmentation import chan_vese
import os
from skimage.filters import threshold_otsu
from scipy import ndimage
from skimage import data
from PIL import Image
from PIL import ImageFilter
import math


def round_down(n, decimals):
    multiplier = 10 ** decimals
    return math.floor(n * multiplier) / multiplier


def get_size(filepath):
    width, height = Image.open(filepath).size
    return width, height


def get_num_pixels(filepath):
    width, height = Image.open(filepath).size
    image_Area = width*height
    return image_Area


def get_Perimeter_Image(filepath):
    width, height = Image.open(filepath).size
    Image_Perimeter = width*2 + 2*height
    return Image_Perimeter


def Median(img, Kernel):
    """Median Filter for pictures Denoising"""
    # To remove the thin hair and other noises like air bubble, noise generated in image acquisition by cameras, etc.
    # median flter of Kernel size 5 is applied in the pre-processing step after Dull-Razor algorithm
    median = cv2.medianBlur(img, Kernel)
    return median

# count the Black  pixels


def cntBlack(file_path):
    img = cv2.imread(file_path)
    Gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cntNotBlack = cv2.countNonZero(Gray)

# get pixel count of image
    height, width = Gray.shape
    cntPixels = height*width

# compute all black pixels
    cntBlack_Pixels = cntPixels - cntNotBlack
    return cntBlack_Pixels


def Otsu(img_Median, file_path):
    """ Otsu’s thresholding method"""
    # Otsu’s method converts the grayscale image to a binary image by global thresholding.

    cntBlack_Pixels = cntBlack(file_path)

    # For the uncropped images with pure Black Background:  The otsu will consider the Black area as area of interest
    # Solution: get rid of pure Blackbackground befor Segmentation to the right area of interest(lesion)
    if cntBlack_Pixels != 0:
        hsv_low = np.array([1, 1, 1])
        hsv_high = np.array([250, 250, 250])
        hsv = cv2.cvtColor(img_Median, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, hsv_low, hsv_high)
        res = cv2.bitwise_and(img_Median, img_Median, mask=mask)
        Gray = cv2.cvtColor(img_Median, cv2.COLOR_BGR2GRAY)
        ret, thresh = cv2.threshold(
            Gray, 0, 255, cv2.THRESH_OTSU)

    # For normal images without Black Background: No Problem with Segmentation: Otsu get with no Problem the lesion as area of interest
    else:
        Gray = cv2.cvtColor(img_Median, cv2.COLOR_BGR2GRAY)
        ret, thresh = cv2.threshold(
            Gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    return ret, thresh


'''Extract the contour from the Binary image'''


def extract_largest_contour(thresh, file_path):
    mask_contours, hierarchy = \
        cv2.findContours(thresh, cv2.RETR_TREE,
                         cv2.CHAIN_APPROX_NONE)
    cnt = len(mask_contours)
    decimal = len(str(get_num_pixels(file_path)))

    # Parameter to remove the false largest_contour: In case where the contour area approximately as big as the whole area of the image
    false_cnt = int(round_down(get_num_pixels(file_path), -decimal+1))

    if cnt > 0:
        area = np.zeros(cnt)
        max_area = np.zeros(2)

        width, height = get_size(file_path)

        for i in np.arange(cnt):
            moments = cv2.moments(mask_contours[i])

            ar = cv2.contourArea(mask_contours[i])

            contour_centroid = [int(moments['m10'] / (moments['m00'] + 1e-5)),
                                int(moments['m01'] / (moments['m00'] + 1e-5))]

            contour_perimeter = cv2.arcLength(mask_contours[i], True)

            # get rid of some no_lesion area contours like image ISIC_0001254_downsampled and so on: another false contour
            if width / 5 <= contour_centroid[0] <= 0.75*width:
                if height / 5 <= contour_centroid[1] <= 0.8 * height:
                    # ignoring the contour which involve approximately the whole picture: better features extraction
                    if ar <= false_cnt:
                        area[i] = ar

        if cnt > 1:

            # save the best 2 areas
            max_area = np.argpartition(area, -2)[-2:]
            # first take the biggest best one and if there is a Problem with the contour by features exctraction it switches to the second:  This condition is in File Lesion.py
            max_area_pos = max_area[1]
        else:
            max_area = np.argpartition(area, -1)[-1:][0]
            max_area_pos = np.argpartition(area, -1)[-1:][0]

        contours = mask_contours[max_area_pos]

        return contours, area, max_area, mask_contours
    else:
        return []
