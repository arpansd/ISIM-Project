import sys
import os
import json
from time import time
import cv2
import numpy as np
import pandas as pd
from PIL import Image
from PIL import ImageFilter
# custom imports
from Preprocessing import dull_razor, color_constancy
from Otsu_Seg import Median, Otsu, extract_largest_contour, get_size
from Method_ABD import extract_ABD
from C_Method import extract_Colour
import threading
from threading import Thread


class Lesion:
    '''This is the main class and contains methods to perform various steps.
    It essentially performs following steps:
        1. Read a lesion image and validate the image
        2. Preprocess the image by applying dull razor for Hair removal 
           and Shades of Gray for colour constancy
        3. Applying a Median Filter and Segment the lesion using Otsu
        4. Extract features (A, B, C, D) from the lesion
        5. More features extraction: get the mean_red, mean_Blue, mean_Green and mean_Gray
           of the lesions will be in Jupyter throught Color_Chanel_Analysis done
        5. Classification with features Selection will be in Jupyter-file done  

    '''

    def __init__(self, file_path):
        """
        Initiate the program by reading the lesion image from the file_path.
        :param file_path:

        """
        self.file_path = file_path
        self.base_file, _ = os.path.splitext(file_path)
        self.original_image = cv2.imread(file_path)
        self.image = None
        self.preprocessed_image = None
        self.Filtered_image = None
        self.thresh = None
        self.segmented_img = None
        self.hsv_image = None
        self.contour_binary = None
        self.contour_image = None
        self.contour_mask = None
        self.warp_img_segmented = None
        self.color_contour = None
        self.asymmetry_vertical = None
        self.asymmetry_horizontal = None
        self.results = None
        self.area = None
        self.area_max = None
        self.mask_contour = None
        # dataset related params (PH2)
        # From: https://doi.org/10.1007/s42452-019-0786-8
        self.hsv_colors = {
            'Blue Gray': [np.array([125, 100, 0]),
                          np.array([150, 150, 150]),
                          (0, 153, 0), 'BG'],  # draw with Green (contour colour by showing the image when usung cv.imshow)
            'White': [np.array([204, 204, 204]),
                      np.array([250, 250, 250]),
                      (255, 255, 0), 'W'],  # draw with Cyan
            'Light Brown': [np.array([0, 51, 150]),
                            np.array([100, 150, 240]), (0, 255, 255), 'LB'],  # draw with Yellow
            'Dark Brown': [np.array([0, 0, 62]),
                           np.array([100, 100, 143]),
                           (255, 0, 0), 'DB'],  # draw with Blue
            'Red': [np.array([0, 0, 150]),
                    np.array([182, 193, 255]),
                    (0, 0, 204), 'R'],  # draw with Red
            'Black': [np.array([5, 5, 5]), np.array([62, 62, 62]),
                      (0, 0, 0), 'B'],  # draw with Black
        }

        self.isImageValid = False
        self.contour = None
        self.max_lesion_diameter = None
        self.max_area_pos = None
        self.contour_area = None
        self.feature_set = []
        self.performance_metric = []
        self.cols = ['A1', 'A2', 'B1', 'B2', 'B3', 'C', 'A_B', 'A_R', 'A_BG', 'A_DB', 'A_LB',
                     'A_W', 'D1', 'D2']
        self.cols1 = ['Path', 'A1', 'A2', 'B1', 'B2', 'B3', 'C', 'A_B', 'A_R', 'A_BG', 'A_DB', 'A_LB',
                      'A_W', 'D1', 'D2']

    def preprocess(self):
        """
        Validate the image and preprocess the image by applying dull Razor for denoising and 
        Hair removal and Shades of Gray.

        """
        try:
            if self.original_image is None:
                self.isImageValid = False
                return
            if self.original_image.shape[2] != 3:
                self.isImageValid = False
                return

            self.image = self.original_image.copy()
            # dull Razor
            self.image = dull_razor(self.image, ksize=(39, 39))
            # Shades of Gray
            self.preprocessed_image = color_constancy(
                self.image, pw=6, gamma=None)
            # For feature colour extraction
            self.hsv_image = cv2.cvtColor(
                self.preprocessed_image, cv2.COLOR_BGR2HSV)
            self.contour_image = np.copy(self.preprocessed_image)

            self.isImageValid = True
        except:
            print("error")
            self.isImageValid = False
            return

    def segment(self):
        '''This method performs segmentation using Otsu’s thresholding method'''

        if self.isImageValid:
            # To remove the thin hair and other noises like air bubble, noise generated in image acquisition by cameras, etc.
            self.Filtered_image = Median(self.preprocessed_image, Kernel=9)
            # Otsu’s method converts the grayscale image to a binary image by global thresholding.
            _, self.thresh = Otsu(self.Filtered_image, self.file_path)
            # Extraction of the largest contour
            self.contour, self.area, self.max_area, self.mask_contour = extract_largest_contour(
                self.thresh, self.file_path)
            count = 0
            for i in range(len(self.area)):
                if self.area[i] == 0:
                    count += 1
                    # print(count)
            if count == len(self.area):
                # solving the segmentation_Problem of uncropped Images: No pure Black Background (not able to count as Black Pixels) Otsu get a false area of interest like by the pure Black Image
                # For convenience: no pure uncropped Black images like ISIC_0000006 and Pure Black Pixels  uncropped images like ISIC_0000004
                # Setting the points to cropp the  image
                width, height = get_size(self.file_path)
                x = int(round(width / 10))
                y = int(round(height / 10))
                w = int(round(9*width/10))
                h = int(round(9*height/10))

                self.image = self.original_image.copy()
                self.image = self.image[y:h, x:w]
                # dull Razor
                self.image = dull_razor(self.image, ksize=(39, 39))
                # Shades of Gray
                self.preprocessed_image = color_constancy(
                    self.image, pw=6, gamma=None)
                # Median Filter
                self.Filtered_image = Median(self.preprocessed_image, Kernel=9)
                # Otsu
                _, self.thresh = Otsu(self.Filtered_image, self.file_path)
                self.contour, self.area, self.max_area, self.mask_contour = extract_largest_contour(
                    self.thresh, self.file_path)

            # cv2.drawContours(self.image, self.contour, -1, (0, 255, 0), 3)
            # cv2.imshow('Image', self.image)
            # cv2.waitKey(0)

            self.contour_area = cv2.contourArea(self.contour)
            if len(self.contour) == 0:
                print('No contours found')

    def extract_features(self):
        """This method is used to extract features (A1,A2,B1,B2,B3,D1,D2) from Method_ABD.py"""
        # From: https://doi.org/10.1007/s42452-019-0786-8

        returnVars = extract_ABD(self.preprocessed_image,
                                 self.thresh,
                                 self.contour)
        if len(returnVars) == 0:
            max_area_pos = self.max_area[0]
            self.contour = self.mask_contour[max_area_pos]
            returnVars = extract_ABD(self.preprocessed_image,
                                     self.thresh,
                                     self.contour)
            self.feature_set = returnVars[0]
            self.asymmetry_horizontal = returnVars[1]
            self.asymmetry_vertical = returnVars[2]
            self.warp_img_segmented = returnVars[3]
            self.max_lesion_diameter = returnVars[4]['D_max']

        else:
            self.feature_set = returnVars[0]
            self.asymmetry_horizontal = returnVars[1]
            self.asymmetry_vertical = returnVars[2]
            self.warp_img_segmented = returnVars[3]
            self.max_lesion_diameter = returnVars[4]['D_max']

    def get_color_contours(self):
        """This method is used to extract color contours of different regions of the lesion"""
        # tolerance = 30
        # self.value_threshold = np.uint8(cv2.mean(self.hsv_image)[2]) \
        #     - tolerance
        # Only the lesion will be colored and the rest of image will be masked to get only the colors contours of the lesion
        self.segmented_img = cv2.bitwise_and(self.preprocessed_image, self.preprocessed_image,
                                             mask=self.thresh)
        self.segmented_img[self.segmented_img == 0] = 255
        hsv = cv2.cvtColor(self.segmented_img, cv2.COLOR_BGR2HSV)
        no_of_colors = []
        self.color_contour = np.copy(self.preprocessed_image)

        for color in self.hsv_colors:

            cnt = extract_Colour(self.segmented_img, hsv,
                                 self.hsv_colors[color],
                                 self.contour_area, self.file_path)

            centroid = []
            color_attr = {}
            if len(cnt) > 0:
                for contour in cnt:
                    moments = cv2.moments(contour)
                    if moments['m00'] == 0:
                        continue
                    color_ctrd = [int(moments['m10'] / moments['m00']),
                                  int(moments['m01'] / moments['m00'])]

                    centroid.append(color_ctrd)
            if len(centroid) != 0:
                cv2.drawContours(self.color_contour, cnt, -1,
                                 self.hsv_colors[color][2],
                                 2)

                asym_color = np.mean(np.array(centroid), axis=0)
                dist = ((asym_color[0] -
                         self.feature_set['centroid'][
                             0]) ** 2 + (asym_color[1] -
                                         self.feature_set['centroid'][
                                             1]) ** 2) ** 0.5
                color_attr['color'] = color
                color_attr['centroids'] = centroid
                self.feature_set['A_' + self.hsv_colors[color][3]] = \
                    round(dist / self.max_lesion_diameter, 4)
                no_of_colors.append(color_attr)
            else:
                self.feature_set['A_' + self.hsv_colors[color][3]] = 0
        self.feature_set['image'] = self.file_path
        cv2.imshow('Image', self.color_contour)
        cv2.waitKey(0)
        self.feature_set['colors_attr'] = no_of_colors
        self.feature_set['C'] = len(no_of_colors)
        self.feature_set['Path'] = self.base_file
